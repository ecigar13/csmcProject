var $ = require('jquery');
// window.$ = $;
// window.jQuery = $;
global.$ = $;
global.jQuery = $;

require('moment');
require('fullcalendar');

// $(function() {
//    $('#calendar').fullCalendar();
// });