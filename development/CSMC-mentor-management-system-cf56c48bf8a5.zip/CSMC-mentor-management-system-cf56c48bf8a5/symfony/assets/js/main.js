// import $ from 'jquery';
// import 'moment';
// import 'fullcalendar';

$(function() {
   $('#calendar').fullCalendar({

   });
});