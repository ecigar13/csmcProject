// import * as $ from 'jquery';
require('fullcalendar');

$(function() {
   var container = $('#calendar');
   container.fullCalendar({
   });
});