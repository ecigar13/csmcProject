<?php

namespace App\DataTransferObject;

class FileData {
    public $file;
    public $user;
}