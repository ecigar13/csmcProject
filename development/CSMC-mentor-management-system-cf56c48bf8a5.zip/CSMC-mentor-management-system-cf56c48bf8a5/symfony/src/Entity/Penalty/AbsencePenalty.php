<?php


namespace App\Entity\Penalty;


use Doctrine\ORM\Mapping as ORM;

/**
 * **Important Note:** Do *NOT* instantiate/modify this class directly! Use an instance of the
 * @see AttendancePenaltyPersistenceManager instead.
 *
 * @package App\Entity\Penalty
 * @internal see notice
 * @ORM\Entity
 */
class AbsencePenalty extends AttendancePenalty
{

}