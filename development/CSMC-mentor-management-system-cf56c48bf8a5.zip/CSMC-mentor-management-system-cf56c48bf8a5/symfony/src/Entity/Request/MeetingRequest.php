<?php

class MeetingRequest {

}