<?php

namespace App\Entity\Event;

class Meeting {
    private $request;
}