<?php


namespace App\Entity\Occurrence;


use Doctrine\ORM\Mapping as ORM;

/**
 * This class has no functionality, it is simply used to group occurrences of attendance type.
 *
 * @ORM\Entity
 *
 * @package App\Entity\Occurrence
 */
abstract class AttendanceOccurrence extends Occurrence
{

}