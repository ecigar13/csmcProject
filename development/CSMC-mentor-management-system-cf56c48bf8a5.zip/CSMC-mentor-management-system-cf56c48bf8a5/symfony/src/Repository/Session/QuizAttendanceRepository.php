<?php

namespace App\Repository\Session;

class QuizAttendanceRepository extends AttendanceRepository {

}