<?php

namespace App\Repository\Session;

class SessionTimeSlotRepository extends TimeSlotRepository {

}