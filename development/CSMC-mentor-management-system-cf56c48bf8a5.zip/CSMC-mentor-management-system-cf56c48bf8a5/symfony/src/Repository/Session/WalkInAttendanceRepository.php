<?php

namespace App\Repository\Session;

class WalkInAttendanceRepository extends AttendanceRepository {

}