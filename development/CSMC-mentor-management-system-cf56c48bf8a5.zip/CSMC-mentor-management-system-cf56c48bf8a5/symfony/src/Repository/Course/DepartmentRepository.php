<?php

namespace App\Repository\Course;

use Doctrine\ORM\EntityRepository;

class DepartmentRepository extends EntityRepository {

}