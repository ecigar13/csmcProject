<?php

namespace App\Repository\Course;

use Doctrine\ORM\EntityRepository;

class CourseRepository extends EntityRepository {

}