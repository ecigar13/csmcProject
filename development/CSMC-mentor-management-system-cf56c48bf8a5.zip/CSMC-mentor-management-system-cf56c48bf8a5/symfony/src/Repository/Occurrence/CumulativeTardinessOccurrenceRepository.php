<?php
/**
 * Created by IntelliJ IDEA.
 * User: mavis
 * Date: 10/27/18
 * Time: 6:11 PM
 */

namespace App\Repository\Occurrence;


use Doctrine\ORM\EntityRepository;

class CumulativeTardinessOccurrenceRepository extends EntityRepository
{

}