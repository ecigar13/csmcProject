<?php

namespace App\Repository\Schedule;

use Doctrine\ORM\EntityRepository;

class ScheduledShiftRepository extends EntityRepository {

}