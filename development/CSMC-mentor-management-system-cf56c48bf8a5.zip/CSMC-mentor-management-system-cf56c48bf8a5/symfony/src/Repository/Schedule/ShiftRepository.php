<?php

namespace App\Repository\Schedule;


use Doctrine\ORM\EntityRepository;

class ShiftRepository extends EntityRepository {

}